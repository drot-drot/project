*Jika kalian ingin menambahkan gambar atau icon ke website ini silahkan simpan di folder img.
*Di folder templates terdapat 5 file html yang dapat diedit oleh kalian, terdapat petunjuk untuk edit nya di dalam file tersebut
*Pada index.html, setiap teks hijau menandakan tombol, kalau ingin dihapus, silahkan dihapus dari teks hijau ke teks hijau lagi
*Jika kalian butuh halaman artikel baru, cukup copy artikel yang sudah ada lalu beri nama untuk artikel kalian yang baru
*Kalian bisa lihat di main.py bahwa banyak kode untuk membuka halaman html-nya, kalian bisa tiru kode tersebut jika ingin menambahkan halaman baru